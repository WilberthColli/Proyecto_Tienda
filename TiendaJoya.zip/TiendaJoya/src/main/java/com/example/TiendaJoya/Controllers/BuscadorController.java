package com.example.TiendaJoya.Controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping(value="/formulario")
public class BuscadorController {
	
	public static void main(String[] args) {
		int arreglo[] = {4,1,5,2,3};
	
		int dato;
		
		
	}
	public class FormularioController {
		@RequestMapping(value="/guardar", method=RequestMethod.POST)
		public String guardar (@RequestParam("nombre") String nombre, Model model) {
			model.addAttribute("nombre", nombre);
			
			return "formulario/resultado";

		}
}
