package com.example.TiendaJoya;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TiendaJoyaApplicationTests {

	@Test
	void contextLoads() {
	}

}
